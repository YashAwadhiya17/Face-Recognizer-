# Face Recognition using PCA + LDA + MLP

This project implements a face recognition system using:
- PCA for dimensionality reduction
- LDA for feature extraction
- MLP (Multi-layer Perceptron) for classification

## Project Structure
- `src/data_loader.py` → Load and preprocess dataset
- `src/trainer.py` → Train PCA, LDA, MLP
- `src/predictor.py` → Predict single new image
- `src/utils.py` → Helper functions
- `main.py` → Entry point
- `dataset/faces/` → Training dataset (folders by person)

## How to Run
```bash
pip install -r requirements.txt
python main.py
```

## Dataset
Place your dataset in `dataset/faces/` where each subfolder corresponds to one person.
