from src.data_loader import load_dataset
from src.trainer import train_model, evaluate_model
from src.predictor import predict_single_image
from src.utils import plot_gallery

def main():
    # Load dataset
    X, y, class_names, h, w = load_dataset("dataset/faces/", size=(300, 300))
    print("Dataset loaded:", X.shape, y.shape)

    # Train model
    clf, pca, lda, X_test, y_test, y_pred, y_prob = train_model(X, y, class_names)

    # Evaluate model
    evaluate_model(y_test, y_pred, class_names)

    # Plot predictions
    prediction_titles = []
    for i in range(len(y_pred)):
        true_name = class_names[y_test[i]]
        pred_name = class_names[y_pred[i]]
        result = f"pred: {pred_name}\nprob: {y_prob[i]:.2f}\ntrue: {true_name}"
        prediction_titles.append(result)

    plot_gallery(X_test, prediction_titles, h, w)

    # Test single custom image (optional)
    # predict_single_image("jugnuu.jpg", clf, pca, lda, class_names, h, w)

if __name__ == "__main__":
    main()
