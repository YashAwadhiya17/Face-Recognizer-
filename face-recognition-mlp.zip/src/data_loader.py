import os
import cv2
import numpy as np

def load_dataset(dir_name, size=(300, 300)):
    images, y, class_names = [], [], []
    person_id = 0
    h, w = size

    for person_name in os.listdir(dir_name):
        class_names.append(person_name)
        person_dir = os.path.join(dir_name, person_name)
        for image_name in os.listdir(person_dir):
            image_path = os.path.join(person_dir, image_name)
            img = cv2.imread(image_path)
            if img is None:
                continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            resized = cv2.resize(gray, (h, w))
            images.append(resized.flatten())
            y.append(person_id)
        person_id += 1

    return np.array(images), np.array(y), np.array(class_names), h, w
