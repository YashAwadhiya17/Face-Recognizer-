import cv2
import numpy as np
import matplotlib.pyplot as plt

def predict_single_image(image_path, clf, pca, lda, class_names, h=300, w=300):
    img = cv2.imread(image_path)
    if img is None:
        print("Image not found:", image_path)
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (h, w))
    v = resized.flatten().reshape(1, -1)

    v_pca = pca.transform(v)
    v_lda = lda.transform(v_pca)

    prob = clf.predict_proba(v_lda)[0]
    class_id = np.argmax(prob)
    pred_name = class_names[class_id]
    confidence = np.max(prob)

    print(f"Prediction: {pred_name}, Confidence: {confidence:.2f}")

    plt.imshow(gray, cmap="gray")
    plt.title(f"Pred: {pred_name} ({confidence:.2f})")
    plt.axis("off")
    plt.show()
