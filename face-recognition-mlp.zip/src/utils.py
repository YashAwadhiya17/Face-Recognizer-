import matplotlib.pyplot as plt

def plot_gallery(images, titles, h, w, n_rows=3, n_cols=4):
    plt.figure(figsize=(1.8 * n_cols, 2.4 * n_rows))
    for i in range(min(n_rows * n_cols, len(images))):
        plt.subplot(n_rows, n_cols, i + 1)
        plt.imshow(images[i].reshape((h, w)), cmap=plt.cm.gray)
        plt.title(titles[i], size=10)
        plt.xticks(())
        plt.yticks(())
    plt.show()
