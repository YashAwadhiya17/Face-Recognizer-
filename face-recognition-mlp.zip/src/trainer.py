from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np

def train_model(X, y, class_names):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    # PCA + LDA
    pca = PCA(n_components=150, whiten=True, random_state=42)
    X_train_pca = pca.fit_transform(X_train)
    X_test_pca = pca.transform(X_test)

    lda = LinearDiscriminantAnalysis()
    X_train_lda = lda.fit_transform(X_train_pca, y_train)
    X_test_lda = lda.transform(X_test_pca)

    # Train MLP
    clf = MLPClassifier(
        random_state=1,
        hidden_layer_sizes=(10, 10),
        max_iter=1000,
        verbose=True
    ).fit(X_train_lda, y_train)

    # Predictions
    y_pred, y_prob = [], []
    for face in X_test_lda:
        prob = clf.predict_proba([face])[0]
        y_pred.append(np.argmax(prob))
        y_prob.append(np.max(prob))

    return clf, pca, lda, X_test, y_test, np.array(y_pred), y_prob

def evaluate_model(y_test, y_pred, class_names):
    acc = (y_pred == y_test).mean()
    print("Accuracy:", acc * 100, "%")
    print("\nClassification Report:\n", classification_report(y_test, y_pred, target_names=class_names))
    print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
